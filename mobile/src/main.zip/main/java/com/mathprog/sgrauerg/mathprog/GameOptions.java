package com.mathprog.sgrauerg.mathprog;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.List;

/**
 * Created by sgrauerg on 11/6/15.
 */
public class GameOptions {

    public static final int GAME_TIME = 20;
    public enum probType { PLUS, MINUS, MULT, DIVIDE};

    public class probSettings
    {
        public probType currProbType;
        public boolean probTypeEnabled;
    }

    public int gameTime;
    public Set<probSettings> probTypeSettings;
    public List<probType> activeProbTypes;

    public GameOptions()
    {
        gameTime = GAME_TIME;
        probTypeSettings = new HashSet<probSettings>();
        for (probType currProbType : probType.values())
        {
            probSettings currOpSettings = new probSettings();
            currOpSettings.currProbType = currProbType;
            currOpSettings.probTypeEnabled = true;

            probTypeSettings.add(currOpSettings);
        }

        activeProbTypes = new ArrayList<probType>();
        for (probSettings currProbSettings : probTypeSettings)
        {
            if (currProbSettings.probTypeEnabled == true)
            {
                activeProbTypes.add(currProbSettings.currProbType);
            }
        }
    }

}
