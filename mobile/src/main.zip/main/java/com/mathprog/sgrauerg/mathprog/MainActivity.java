package com.mathprog.sgrauerg.mathprog;

import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.text.method.ScrollingMovementMethod;

import java.util.Calendar;
import java.util.List;


public class MainActivity extends ActionBarActivity {

    private GameOptions currGameOptions = new GameOptions();
    private MathProblem currMathProb = new MathProblem();
    private GameStatus currGameState = new GameStatus();
    private GameTimer gameTimer = new GameTimer(currGameOptions);
    private boolean gameOver = false;
    private Thread timerThread = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startGame();
        TextView tv = (TextView) findViewById(R.id.results);
        tv.setMovementMethod(ScrollingMovementMethod.getInstance());
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        if (timerThread != null) {
            timerThread.interrupt();
        }
    }

    @Override
    protected void onStop()
    {
        super.onStop();

        if (timerThread != null) {
            timerThread.interrupt();
        }

    }

    @Override
    protected void onResume()
    {
        super.onResume();
        if ((timerThread != null) && (timerThread.getState() == Thread.State.TERMINATED)) {
            timer();
        }
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();

        if ((timerThread != null) && (timerThread.getState() == Thread.State.TERMINATED)) {
            timer();
        }
    }

    public void startGame()
    {
        ((Button)findViewById(R.id.button)).setVisibility(View.VISIBLE);
        ((Button)findViewById(R.id.button2)).setVisibility(View.VISIBLE);
        ((Button)findViewById(R.id.button3)).setVisibility(View.VISIBLE);
        ((Button)findViewById(R.id.button4)).setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.leftSideProb)).setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.probOperator)).setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.rightSideProb)).setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.equalProb)).setVisibility(View.VISIBLE);
        ((Button)findViewById(R.id.playAgain)).setVisibility(View.GONE);

        currGameState.startGame();
        gameTimer.startTimer();
        currMathProb.genNewProblem(currGameOptions);
        timer();

        ((TextView)findViewById(R.id.leftSideProb)).setText(currMathProb.getLeftSideStringRep());
        ((TextView)findViewById(R.id.probOperator)).setText(currMathProb.getOpStringRep());
        ((TextView)findViewById(R.id.rightSideProb)).setText(currMathProb.getRightSideStringRep());

        List<Integer> possAnswers = currMathProb.genPossAnswers(4);
        ((Button)findViewById(R.id.button)).setText(Integer.toString(possAnswers.get(0)));
        ((Button)findViewById(R.id.button2)).setText(Integer.toString(possAnswers.get(1)));
        ((Button)findViewById(R.id.button3)).setText(Integer.toString(possAnswers.get(2)));
        ((Button)findViewById(R.id.button4)).setText(Integer.toString(possAnswers.get(3)));

        ((Button)findViewById(R.id.button)).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        processAnswerSubmission(v);
                    }
                });
        ((Button)findViewById(R.id.button2)).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        processAnswerSubmission(v);
                    }
                });
        ((Button)findViewById(R.id.button3)).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        processAnswerSubmission(v);
                    }
                });
        ((Button)findViewById(R.id.button4)).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        processAnswerSubmission(v);
                    }
                });

        ((TextView)findViewById(R.id.numRightTotal)).setText("Answers Correct/Total:    " +
                Integer.toString(currGameState.getNumCorrect()) + " / " +
                Integer.toString(currGameState.getNumCorrect() + currGameState.getNumWrong()));
        String currScoreText = String.format("%.1f", currGameState.getCurrScore());
        ((TextView) findViewById(R.id.score)).setText("Score: " + currScoreText);

        ((TextView) findViewById(R.id.prevAnswerResult)).setTextColor(Color.BLACK);
        ((TextView) findViewById(R.id.prevAnswerResult)).setText("Previous Result: None Yet");
        ((TextView) findViewById(R.id.results)).setText("Results:\n" + currGameState.getAllResultsString());

        currGameState.startQuestion();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void processAnswerSubmission(View v)
    {
        Calendar c = Calendar.getInstance();
        long timeAtPress = c.getTimeInMillis();
        int numOnButton = Integer.parseInt(((Button) v).getText().toString());
        boolean answerCorrect = false;
        currGameState.processResult(currMathProb, numOnButton, timeAtPress);
        if (numOnButton == currMathProb.correctAnswer())
        {
            answerCorrect = true;

        }
        else {
            answerCorrect = false;
        }

        ((TextView)findViewById(R.id.numRightTotal)).setText("Answers Correct/Total:    " + Integer.toString(currGameState.getNumCorrect())
                + " / " + Integer.toString(currGameState.getNumCorrect() + currGameState.getNumWrong()));
        if (answerCorrect)
        {
            ((TextView) findViewById(R.id.prevAnswerResult)).setTextColor(Color.parseColor("#a17f1a"));
            ((TextView) findViewById(R.id.prevAnswerResult)).setText("Prev: CORRECT (" +
                    currMathProb.getLeftSideStringRep() + currMathProb.getOpStringRep() +
                    currMathProb.getRightSideStringRep() + "=" + numOnButton + ")");
        }
        else
        {
            ((TextView) findViewById(R.id.prevAnswerResult)).setTextColor(Color.RED);
            ((TextView) findViewById(R.id.prevAnswerResult)).setText("Prev: WRONG (" +
                    currMathProb.getLeftSideStringRep() + currMathProb.getOpStringRep() +
                    currMathProb.getRightSideStringRep() + "=" + currMathProb.correctAnswer() +
                    " NOT " + numOnButton + ")");
        }
        String currScoreText = String.format("%.1f", currGameState.getCurrScore());
        ((TextView) findViewById(R.id.score)).setText("Score: " + currScoreText);
        ((TextView) findViewById(R.id.results)).setText("Results:\n" + currGameState.getAllResultsString());

        TextView tv = (TextView) findViewById(R.id.results);
        tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        setupNextProblem();
    }

    public void setupNextProblem()
    {
        currMathProb.genNewProblem(currGameOptions);
        ((TextView)findViewById(R.id.leftSideProb)).setText(currMathProb.getLeftSideStringRep());
        ((TextView)findViewById(R.id.probOperator)).setText(currMathProb.getOpStringRep());
        ((TextView)findViewById(R.id.rightSideProb)).setText(currMathProb.getRightSideStringRep());

        List<Integer> possAnswers = currMathProb.genPossAnswers(4);
        ((Button)findViewById(R.id.button)).setText(Integer.toString(possAnswers.get(0)));
        ((Button)findViewById(R.id.button2)).setText(Integer.toString(possAnswers.get(1)));
        ((Button)findViewById(R.id.button3)).setText(Integer.toString(possAnswers.get(2)));
        ((Button)findViewById(R.id.button4)).setText(Integer.toString(possAnswers.get(3)));

        currGameState.startQuestion();
    }

    public void timer()
    {
        timerThread = new Thread(){
            public void run() {
                try
                {
                    float secsLeft = -1;
                    do {
                        Thread.sleep(100);
                        secsLeft = gameTimer.timeLeftInSecs();
                        final String secsLeftPrint = String.format("%.1f", secsLeft);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run()
                            {
                                ((TextView)findViewById(R.id.timeLeft)).setText("Time Left: " + secsLeftPrint);
                            }
                        });
                        if (secsLeft <= 0) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    endGame();
                                    ((TextView)findViewById(R.id.timeLeft)).setText("Time Left: 0.0");
                                }
                            });
                        }
                    } while (secsLeft > 0);
                }
                catch (InterruptedException e)
                {
                    Log.v("EXCEPTION", "ThreadSleepError");
                    return;
                }

            } };

        timerThread.start();
    }

    public void endGame()
    {
        ((Button)findViewById(R.id.button)).setVisibility(View.GONE);
        ((Button)findViewById(R.id.button2)).setVisibility(View.GONE);
        ((Button)findViewById(R.id.button3)).setVisibility(View.GONE);
        ((Button)findViewById(R.id.button4)).setVisibility(View.GONE);
        ((TextView)findViewById(R.id.leftSideProb)).setVisibility(View.GONE);
        ((TextView)findViewById(R.id.probOperator)).setVisibility(View.GONE);
        ((TextView)findViewById(R.id.rightSideProb)).setVisibility(View.GONE);
        ((TextView)findViewById(R.id.equalProb)).setVisibility(View.GONE);

        ((TextView)findViewById(R.id.results)).setText("Results:\n" + currGameState.getAllResultsString());

        ((Button)findViewById(R.id.playAgain)).setVisibility(View.VISIBLE);
        ((Button)findViewById(R.id.playAgain)).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startGame();
                    }
                });
    }
}
